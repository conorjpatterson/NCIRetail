Rails.application.routes.draw do
  resources :entries
  resources :items
  resources :categories
get 'category/:title', to: 'static_pages#category'
  resources :menus, :entries
  #get 'static_pages/home'
  root 'static_pages#home'
  #get 'static_pages/emp'
  root 'entries#index'
  
  
  get '/emp' => 'static_pages#emp'
  
 get '/aboutSend/:id' => 'static_pages#aboutSend'
  
  get '/ent' => 'static_pages#ent'
  
  get '/login', to: 'user#login'
  get '/logout', to: 'user#logout'
  
  
  #root :to => 'static_pages#home'
  root :to => 'site#home'
  
  get 'orderitems/index'

  get 'orderitems/show'

  get 'orderitems/new'

  get 'orderitems/edit'

post '/search' => 'menus#search'
post '/search' => 'entries#search'

  resources :orders do 
    resources:ordermenus
  end

resources :orders do 
    resources:orderentries
  end
  
  devise_for :users do 
    resources :orders
  end
  
  #get 'static_pages/ent'



  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end

