class StaticPagesController < ApplicationController
  def home

   @menus = Menu.all
   @entries = Menu.all
  end

  def help
    
  end
  
  end
 
  
def category
    catName = params[:title]
    @menus = Menu.where("category like ? ", catName)
end

  def category
    catName = params[:title]
    @entries = Entry.where("category like ? ", catName)
end
  



def upgrade_admin
        @user.update_attribute(:adminrole, true)
        redirect_to :action => :admin_users
 end
    
def downgrade_admin
       @user.update_attribute(:adminrole, false)
         redirect_to :action => :admin_users
end    




