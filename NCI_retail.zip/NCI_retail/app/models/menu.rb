class Menu < ApplicationRecord
    
end
