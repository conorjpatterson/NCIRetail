class Entry < ApplicationRecord

end
